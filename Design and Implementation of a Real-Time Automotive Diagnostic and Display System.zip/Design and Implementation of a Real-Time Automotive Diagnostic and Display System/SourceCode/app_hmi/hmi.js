import { initializeApp } from 'https://www.gstatic.com/firebasejs/12.5.0/firebase-app.js';
import { getDatabase, ref, onValue } from 'https://www.gstatic.com/firebasejs/12.5.0/firebase-database.js';

// =================== FIREBASE CONFIG ===================
const firebaseConfig = {
  apiKey: "AIzaSyAuQuHZP4yshXq5qjjKSC83XHE98iHcW1o",
  authDomain: "doan2-5a98c.firebaseapp.com",
  databaseURL: "https://doan2-5a98c-default-rtdb.firebaseio.com",
  projectId: "doan2-5a98c",
  storageBucket: "doan2-5a98c.firebasestorage.app",
  messagingSenderId: "340037417162",
  appId: "1:340037417162:web:1552ed4d8d3102d8a21c33",
  measurementId: "G-M98JZ9657Y"
};

const app = initializeApp(firebaseConfig);
const db  = getDatabase(app);

// =================== NGƯỠNG ===================
const SPEED_MIN   = 0;
const SPEED_MAX   = 160;
const RPM_MIN     = 0;
const RPM_MAX     = 8000;
const COOLANT_MIN = 50;
const COOLANT_MAX = 180;
const FUEL_MIN    = 0;
const FUEL_MAX    = 100;

// Ngưỡng cảnh báo
const FUEL_WARN_THRESHOLD    = 20;    // %
const COOLANT_WARN_THRESHOLD = 115;   // °C
const SPEED_WARN_THRESHOLD   = 120;   // km/h
const RPM_WARN_THRESHOLD     = 6500;  // rpm

// =================== DOM ELEMENTS ===================
const speedValueEl    = document.getElementById("speed-value");
const rpmValueEl      = document.getElementById("rpm-value");
const odometerValueEl = document.getElementById("odometer-value");

const topDateEl = document.getElementById("top-date");
const topTimeEl = document.getElementById("top-time");

const speedCanvas = document.getElementById("speed-canvas");
const rpmCanvas   = document.getElementById("rpm-canvas");

const speedCtx = speedCanvas ? speedCanvas.getContext("2d") : null;
const rpmCtx   = rpmCanvas ? rpmCanvas.getContext("2d") : null;

// cảnh báo + chi tiết coolant/fuel + icon
const warningListEl        = document.getElementById("warning-list");
const coolantDetailValueEl = document.getElementById("coolant-detail-value");
const fuelDetailValueEl    = document.getElementById("fuel-detail-value");
const coolantIconEl        = document.getElementById("coolant-icon");
const fuelIconEl           = document.getElementById("fuel-icon");

const warnSpeedTileEl   = document.getElementById("warning-speed-tile");
const warnFuelTileEl    = document.getElementById("warning-fuel-tile");
const warnCoolantTileEl = document.getElementById("warning-coolant-tile");

// xi-nhan
const leftTurnEl  = document.getElementById("turn-left");
const rightTurnEl = document.getElementById("turn-right");

// PRND
const gearEls = Array.from(document.querySelectorAll(".gear"));

// =================== GEAR ===================

function setGearActive(gearChar) {
  gearEls.forEach(el => {
    const txt = el.textContent.trim().toUpperCase();
    if (txt === gearChar.toUpperCase()) {
      el.classList.add("gear-active");
    } else {
      el.classList.remove("gear-active");
    }
  });
}

/**
 * Quy luật demo:
 * speed < -0.1        => R
 * -0.1 <= speed < 0.5 => P
 * 0.5 <= speed < 5    => N
 * speed >= 5          => D
 */
function updateGearFromSpeed(speedKmh) {
  let gear = "P";

  if (speedKmh < -0.1) {
    gear = "R";
  } else if (speedKmh >= 0.5 && speedKmh < 5) {
    gear = "N";
  } else if (speedKmh >= 5) {
    gear = "D";
  }

  setGearActive(gear);
}

// =================== HELPER ===================
function clamp(v, min, max) {
  return Math.min(max, Math.max(min, v));
}
function valueToRatio(v, min, max) {
  const c = clamp(v, min, max);
  return (c - min) / (max - min);
}
function degToRad(deg) {
  return (deg * Math.PI) / 180;
}

// =================== STATE ===================
let currentSpeed          = 0;   // km/h
let currentCoolantPct     = 40;  // 0..100
let currentCoolantC       = 40;  // °C
let currentRpmK           = 0;   // 0..8 (x1000)
let currentRpm            = 0;   // rpm raw
let currentFuelPct        = 50;  // 0..100 cho gauge
let currentFuelPercentRaw = 50;  // % raw

const MAX_SPEED_CANVAS = 160;
const MAX_RPM_CANVAS   = 8;

// =================== XI-NHAN LOGIC ===================
// "left" | "right" | null
let activeTurnSignal = null;

function setTurnSignal(side) {
  activeTurnSignal = side;

  if (leftTurnEl) {
    if (side === "left") leftTurnEl.classList.add("turn-signal-active");
    else leftTurnEl.classList.remove("turn-signal-active");
  }

  if (rightTurnEl) {
    if (side === "right") rightTurnEl.classList.add("turn-signal-active");
    else rightTurnEl.classList.remove("turn-signal-active");
  }
}

if (leftTurnEl) {
  leftTurnEl.addEventListener("click", () => {
    if (activeTurnSignal === "left") setTurnSignal(null);
    else setTurnSignal("left");
  });
}

if (rightTurnEl) {
  rightTurnEl.addEventListener("click", () => {
    if (activeTurnSignal === "right") setTurnSignal(null);
    else setTurnSignal("right");
  });
}

// =================== GAUGE TỐC ĐỘ ===================

function drawSpeedGauge() {
  if (!speedCtx || !speedCanvas) return;

  const w = speedCanvas.width;
  const h = speedCanvas.height;
  const cx = w / 2;
  const cy = h / 2;
  const radius = Math.min(w, h) / 2;

  const speed       = currentSpeed;
  const tempPercent = currentCoolantPct;

  speedCtx.clearRect(0, 0, w, h);
  speedCtx.save();
  speedCtx.translate(cx, cy);

  // 1. viền kim loại ngoài
  const metalRadius = radius * 0.83;
  const metalGrad = speedCtx.createLinearGradient(
    -metalRadius,
    -metalRadius,
    metalRadius,
    metalRadius
  );
  metalGrad.addColorStop(0, "#9a9ea7");
  metalGrad.addColorStop(0.25, "#f5f7ff");
  metalGrad.addColorStop(0.5, "#6f737c");
  metalGrad.addColorStop(0.75, "#f5f7ff");
  metalGrad.addColorStop(1, "#4f535a");

  speedCtx.fillStyle = metalGrad;
  speedCtx.beginPath();
  speedCtx.arc(0, 0, metalRadius, 0, Math.PI * 2);
  speedCtx.fill();

  // 2. nền đen trong
  const baseRadius = radius * 0.78;
  const bgGrad = speedCtx.createRadialGradient(0, 0, 0, 0, 0, baseRadius);
  bgGrad.addColorStop(0, "#050608");
  bgGrad.addColorStop(0.5, "#050608");
  bgGrad.addColorStop(1, "#000000");

  speedCtx.fillStyle = bgGrad;
  speedCtx.beginPath();
  speedCtx.arc(0, 0, baseRadius, 0, Math.PI * 2);
  speedCtx.fill();

  speedCtx.strokeStyle = "rgba(255,255,255,0.85)";
  speedCtx.lineWidth = 2;
  speedCtx.beginPath();
  speedCtx.arc(0, 0, baseRadius - 2, 0, Math.PI * 2);
  speedCtx.stroke();

  // 3. vạch – vòng màu
  const startAngle = degToRad(150);
  const sweepAngle = degToRad(240);
  const frac = Math.min(Math.max(speed / MAX_SPEED_CANVAS, 0), 1);
  const activeSweep = sweepAngle * frac;

  const outerRadius      = radius * 0.72;
  const innerBlackRadius = radius * 0.34;

  // nền vạch tối
  speedCtx.lineCap = "round";
  speedCtx.lineWidth = 10;
  speedCtx.strokeStyle = "#202328";
  speedCtx.beginPath();
  speedCtx.arc(0, 0, outerRadius, startAngle, startAngle + sweepAngle);
  speedCtx.stroke();

  // phần còn lại xanh (phía sau kim)
  speedCtx.lineWidth = 9;
  speedCtx.strokeStyle = "rgba(0, 180, 190, 0.6)";
  speedCtx.beginPath();
  speedCtx.arc(
    0,
    0,
    outerRadius,
    startAngle + activeSweep,
    startAngle + sweepAngle
  );
  speedCtx.stroke();

  // phần từ 0 -> speed: đỏ cam
  const gradArc = speedCtx.createLinearGradient(
    -outerRadius,
    -outerRadius,
    outerRadius,
    outerRadius
  );
  gradArc.addColorStop(0, "#ff9a1a");
  gradArc.addColorStop(0.5, "#ff4b2b");
  gradArc.addColorStop(1, "#ff1f3d");

  speedCtx.lineWidth = 12;
  speedCtx.strokeStyle = gradArc;
  speedCtx.beginPath();
  speedCtx.arc(0, 0, outerRadius, startAngle, startAngle + activeSweep);
  speedCtx.stroke();

  // vạch + số
  drawSpeedTicksAndLabels(speedCtx, startAngle, sweepAngle, outerRadius);

  // 4. nền đen trong cùng
  const innerGrad = speedCtx.createRadialGradient(
    0,
    0,
    innerBlackRadius * 0.1,
    0,
    0,
    innerBlackRadius
  );
  innerGrad.addColorStop(0, "#191b22");
  innerGrad.addColorStop(0.55, "#050608");
  innerGrad.addColorStop(0.85, "#020203");
  innerGrad.addColorStop(1, "rgba(0,0,0,0)");

  speedCtx.fillStyle = innerGrad;
  speedCtx.beginPath();
  speedCtx.arc(0, 0, innerBlackRadius, 0, Math.PI * 2);
  speedCtx.fill();

  // 5. vòng mảnh highlight + halo nhỏ quanh tâm
  const ringRadius = innerBlackRadius + (outerRadius - innerBlackRadius) * 0.32;

  const ringGrad = speedCtx.createLinearGradient(-ringRadius, 0, ringRadius, 0);
  ringGrad.addColorStop(0, "rgba(255, 255, 255, 0.25)");
  ringGrad.addColorStop(0.5, "rgba(255, 160, 70, 0.95)");
  ringGrad.addColorStop(1, "rgba(255, 255, 255, 0.25)");

  speedCtx.strokeStyle = ringGrad;
  speedCtx.lineWidth = 2.2;
  speedCtx.beginPath();
  speedCtx.arc(0, 0, ringRadius, 0, Math.PI * 2);
  speedCtx.stroke();

  // halo chỉ ôm sát vòng, không che số
  const haloInnerR = ringRadius - 2;
  const haloOuterR = ringRadius + 8;

  const haloGrad = speedCtx.createRadialGradient(
    0, 0, haloInnerR,
    0, 0, haloOuterR
  );
  haloGrad.addColorStop(0.0, "rgba(255, 160, 70, 0.35)");
  haloGrad.addColorStop(0.5, "rgba(255, 100, 30, 0.18)");
  haloGrad.addColorStop(1.0, "rgba(0, 0, 0, 0)");

  speedCtx.fillStyle = haloGrad;
  speedCtx.beginPath();
  speedCtx.arc(0, 0, haloOuterR, 0, Math.PI * 2);
  speedCtx.arc(0, 0, haloInnerR, 0, Math.PI * 2, true);
  speedCtx.closePath();
  speedCtx.fill();

  // 6. dải sáng neon chạy theo speed
  const glowInnerR = innerBlackRadius * 1.0;
  const glowOuterR = outerRadius * 1.0;
  const baseAlpha  = 0.04;
  const extraAlpha = 0.08 * frac;

  const glowGradSpeed = speedCtx.createRadialGradient(
    0, 0, glowInnerR,
    0, 0, glowOuterR
  );
  glowGradSpeed.addColorStop(
    0.0,
    `rgba(255, 240, 220, ${baseAlpha + extraAlpha * 1.6})`
  );
  glowGradSpeed.addColorStop(
    0.35,
    `rgba(255, 205, 150, ${baseAlpha + extraAlpha})`
  );
  glowGradSpeed.addColorStop(
    1.0,
    `rgba(255, 170, 100, 0)`
  );

  speedCtx.fillStyle = glowGradSpeed;
  speedCtx.beginPath();
  speedCtx.arc(0, 0, glowOuterR, startAngle, startAngle + activeSweep);
  speedCtx.arc(
    0,
    0,
    glowInnerR,
    startAngle + activeSweep,
    startAngle,
    true
  );
  speedCtx.closePath();
  speedCtx.fill();

  // 7. kim tốc độ
  const angleNeedle = startAngle + sweepAngle * frac;

  speedCtx.save();
  speedCtx.rotate(angleNeedle);

  const pivotRadius = innerBlackRadius + (outerRadius - innerBlackRadius) * 0.38;
  speedCtx.translate(pivotRadius, 0);

  const needleLength = outerRadius - pivotRadius - 3;
  const halfWidth = 3;

  const needleGrad = speedCtx.createLinearGradient(
    0,
    0,
    needleLength,
    0
  );
  needleGrad.addColorStop(0, "rgba(255,255,255,0.05)");
  needleGrad.addColorStop(0.4, "#ff6a3a");
  needleGrad.addColorStop(1, "#ff1f3d");

  speedCtx.fillStyle = needleGrad;
  speedCtx.beginPath();
  speedCtx.moveTo(0, -halfWidth);
  speedCtx.lineTo(needleLength, 0);
  speedCtx.lineTo(0, halfWidth);
  speedCtx.closePath();
  speedCtx.fill();

  speedCtx.restore();

  // 8. vòng C/H ngoài
  drawTempArcOnSpeed(speedCtx, radius, tempPercent);

  speedCtx.restore();
}

// vạch + số speed metallic + nhiều mức
function drawSpeedTicksAndLabels(ctx, startAngle, sweepAngle, radius) {
  const max       = MAX_SPEED_CANVAS;
  const majorStep = 20; // 0,20,40...
  const minorStep = 5;  // thêm vạch 5 km/h

  ctx.save();

  for (let value = 0; value <= max; value += minorStep) {
    const frac  = value / max;
    const angle = startAngle + sweepAngle * frac;

    const isBig    = value % majorStep === 0;
    const isMedium = !isBig && value % 10 === 0;
    const isSmall  = !isBig && !isMedium;

    const isDanger = value >= 100;

    const outerR = radius;
    let innerR;
    if (isBig) innerR = radius - 20;
    else if (isMedium) innerR = radius - 15;
    else innerR = radius - 11;

    const cosA = Math.cos(angle);
    const sinA = Math.sin(angle);

    const outerX = outerR * cosA;
    const outerY = outerR * sinA;
    const innerX = innerR * cosA;
    const innerY = innerR * sinA;

    // bóng dưới vạch
    ctx.beginPath();
    ctx.lineWidth   = isBig ? 3.6 : (isMedium ? 2.6 : 2.0);
    ctx.strokeStyle = "rgba(0,0,0,0.6)";
    ctx.moveTo(innerX + 1.2 * cosA, innerY + 1.2 * sinA);
    ctx.lineTo(outerX + 1.2 * cosA, outerY + 1.2 * sinA);
    ctx.stroke();

    // vạch chính
    const grad = ctx.createLinearGradient(innerX, innerY, outerX, outerY);
    if (isDanger) {
      grad.addColorStop(0.0, "#4b000a");
      grad.addColorStop(0.4, "#ff9aa5");
      grad.addColorStop(0.8, "#ff3b4b");
      grad.addColorStop(1.0, "#2b0005");
    } else {
      if (isBig) {
        grad.addColorStop(0.0, "#191b22");
        grad.addColorStop(0.4, "#f5f7ff");
        grad.addColorStop(0.8, "#c3c7d2");
        grad.addColorStop(1.0, "#4c505b");
      } else if (isMedium) {
        grad.addColorStop(0.0, "rgba(235,238,245,0.9)");
        grad.addColorStop(1.0, "rgba(170,175,190,0.95)");
      } else {
        grad.addColorStop(0.0, "rgba(210,215,225,0.7)");
        grad.addColorStop(1.0, "rgba(150,155,170,0.85)");
      }
    }

    ctx.beginPath();
    ctx.lineWidth   = isBig ? 3.0 : (isMedium ? 2.2 : 1.8);
    ctx.strokeStyle = grad;
    ctx.moveTo(innerX, innerY);
    ctx.lineTo(outerX, outerY);
    ctx.stroke();

    // số lớn
    if (isBig) {
      const labelR = radius - 28;
      const lx = labelR * cosA;
      const ly = labelR * sinA;

      ctx.save();
      ctx.translate(lx, ly);
      const textStr = String(value);

      ctx.font = "15px system-ui";
      ctx.textAlign = "center";
      ctx.textBaseline = "middle";

      ctx.fillStyle = "rgba(0,0,0,0.85)";
      ctx.fillText(textStr, 1.2, 1.6);

      const textGrad = ctx.createLinearGradient(-12, -8, 12, 8);
      if (isDanger) {
        textGrad.addColorStop(0.0, "#5a050f");
        textGrad.addColorStop(0.4, "#ffb0b8");
        textGrad.addColorStop(0.8, "#ff4d5a");
        textGrad.addColorStop(1.0, "#2b0207");
      } else {
        textGrad.addColorStop(0.0, "#d0d3dc");
        textGrad.addColorStop(0.4, "#ffffff");
        textGrad.addColorStop(0.8, "#b0b4c0");
        textGrad.addColorStop(1.0, "#5a5f6a");
      }

      ctx.fillStyle = textGrad;
      ctx.fillText(textStr, 0, 0);

      ctx.lineWidth = 0.8;
      ctx.strokeStyle = "rgba(255,255,255,0.55)";
      ctx.strokeText(textStr, 0, 0);

      ctx.restore();
    }
  }

  ctx.restore();
}

// C/H arc trên speed
function drawTempArcOnSpeed(ctx, radius, tempPercent) {
  ctx.save();

  const margin     = 6;
  const tempRadius = radius - margin;

  const angleC = degToRad(225);
  const angleH = degToRad(135);

  const frac = Math.max(0, Math.min(1, tempPercent / 100));

  const numTicks = 50;
  for (let i = 0; i <= numTicks; i++) {
    const t   = i / numTicks;
    const ang = angleH + (angleC - angleH) * t;

    const rOuter = tempRadius + 4;
    const rInner = tempRadius - 6;

    const xOuter = rOuter * Math.cos(ang);
    const yOuter = rOuter * Math.sin(ang);
    const xInner = rInner * Math.cos(ang);
    const yInner = rInner * Math.sin(ang);

    const active = t <= frac + 1e-4;

    let color;
    if (!active) {
      color = "rgba(255,255,255,0.18)";
    } else {
      if (t < 0.5) {
        const k = t / 0.5;
        const g = Math.round(255 * k);
        const b = Math.round(255 + (157 - 255) * k);
        color = `rgba(0,${g},${b},0.95)`;
      } else {
        const k = (t - 0.5) / 0.5;
        const r = Math.round(255 * k);
        const g = Math.round(255 + (59 - 255) * k);
        const b = Math.round(157 + (47 - 157) * k);
        color = `rgba(${r},${g},${b},0.95)`;
      }
    }

    ctx.beginPath();
    ctx.lineWidth   = 4;
    ctx.strokeStyle = color;
    ctx.moveTo(xInner, yInner);
    ctx.lineTo(xOuter, yOuter);
    ctx.stroke();
  }

  const labelRadius = tempRadius + 14;
  ctx.fillStyle     = "#ffffff";
  ctx.font          = "13px system-ui";
  ctx.textAlign     = "center";
  ctx.textBaseline  = "middle";

  const xC = labelRadius * Math.cos(angleC);
  const yC = labelRadius * Math.sin(angleC);
  ctx.fillText("H", xC, yC);

  const xH = labelRadius * Math.cos(angleH);
  const yH = labelRadius * Math.sin(angleH);
  ctx.fillText("C", xH, yH);

  ctx.restore();
}

// =================== GAUGE RPM ===================

function drawRpmGauge() {
  if (!rpmCtx || !rpmCanvas) return;

  const w = rpmCanvas.width;
  const h = rpmCanvas.height;
  const cx = w / 2;
  const cy = h / 2;
  const radius = Math.min(w, h) / 2;

  const rpmK        = currentRpmK;
  const fuelPercent = currentFuelPct;

  rpmCtx.clearRect(0, 0, w, h);
  rpmCtx.save();
  rpmCtx.translate(cx, cy);

  const metalRadius = radius * 0.83;
  const metalGrad = rpmCtx.createLinearGradient(
    -metalRadius,
    -metalRadius,
    metalRadius,
    metalRadius
  );
  metalGrad.addColorStop(0, "#9a9ea7");
  metalGrad.addColorStop(0.25, "#f5f7ff");
  metalGrad.addColorStop(0.5, "#6f737c");
  metalGrad.addColorStop(0.75, "#f5f7ff");
  metalGrad.addColorStop(1, "#4f535a");

  rpmCtx.fillStyle = metalGrad;
  rpmCtx.beginPath();
  rpmCtx.arc(0, 0, metalRadius, 0, Math.PI * 2);
  rpmCtx.fill();

  const baseRadius = radius * 0.78;
  const bgGrad = rpmCtx.createRadialGradient(0, 0, 0, 0, 0, baseRadius);
  bgGrad.addColorStop(0, "#050608");
  bgGrad.addColorStop(0.5, "#050608");
  bgGrad.addColorStop(1, "#000000");

  rpmCtx.fillStyle = bgGrad;
  rpmCtx.beginPath();
  rpmCtx.arc(0, 0, baseRadius, 0, Math.PI * 2);
  rpmCtx.fill();

  rpmCtx.strokeStyle = "rgba(255,255,255,0.85)";
  rpmCtx.lineWidth = 2;
  rpmCtx.beginPath();
  rpmCtx.arc(0, 0, baseRadius - 2, 0, Math.PI * 2);
  rpmCtx.stroke();

  const startAngle = degToRad(150);
  const sweepAngle = degToRad(240);
  const frac = Math.min(Math.max(rpmK / MAX_RPM_CANVAS, 0), 1);
  const activeSweep = sweepAngle * frac;

  const outerRadius      = radius * 0.72;
  const innerBlackRadius = radius * 0.34;

  rpmCtx.lineCap = "round";
  rpmCtx.lineWidth = 10;
  rpmCtx.strokeStyle = "#202328";
  rpmCtx.beginPath();
  rpmCtx.arc(0, 0, outerRadius, startAngle, startAngle + sweepAngle);
  rpmCtx.stroke();

  rpmCtx.lineWidth = 9;
  rpmCtx.strokeStyle = "rgba(0, 180, 190, 0.6)";
  rpmCtx.beginPath();
  rpmCtx.arc(
    0,
    0,
    outerRadius,
    startAngle + activeSweep,
    startAngle + sweepAngle
  );
  rpmCtx.stroke();

  const gradArc = rpmCtx.createLinearGradient(
    -outerRadius,
    -outerRadius,
    outerRadius,
    outerRadius
  );
  gradArc.addColorStop(0, "#ffce3a");
  gradArc.addColorStop(0.5, "#ff9a1a");
  gradArc.addColorStop(1, "#ff6a00");

  rpmCtx.lineWidth = 12;
  rpmCtx.strokeStyle = gradArc;
  rpmCtx.beginPath();
  rpmCtx.arc(0, 0, outerRadius, startAngle, startAngle + activeSweep);
  rpmCtx.stroke();

  drawRpmTicksAndLabels(rpmCtx, startAngle, sweepAngle, outerRadius);

  const innerGrad = rpmCtx.createRadialGradient(
    0,
    0,
    innerBlackRadius * 0.1,
    0,
    0,
    innerBlackRadius
  );
  innerGrad.addColorStop(0, "#191b22");
  innerGrad.addColorStop(0.45, "#050608");
  innerGrad.addColorStop(0.8, "#020203");
  innerGrad.addColorStop(1, "rgba(0,0,0,0)");

  rpmCtx.fillStyle = innerGrad;
  rpmCtx.beginPath();
  rpmCtx.arc(0, 0, innerBlackRadius, 0, Math.PI * 2);
  rpmCtx.fill();

  // vòng highlight mảnh + halo
  const ringRadiusRpm = innerBlackRadius + (outerRadius - innerBlackRadius) * 0.32;

  const ringGradRpm = rpmCtx.createLinearGradient(-ringRadiusRpm, 0, ringRadiusRpm, 0);
  ringGradRpm.addColorStop(0, "rgba(255, 255, 255, 0.25)");
  ringGradRpm.addColorStop(0.5, "rgba(255, 200, 80, 0.95)");
  ringGradRpm.addColorStop(1, "rgba(255, 255, 255, 0.25)");

  rpmCtx.strokeStyle = ringGradRpm;
  rpmCtx.lineWidth = 2.2;
  rpmCtx.beginPath();
  rpmCtx.arc(0, 0, ringRadiusRpm, 0, Math.PI * 2);
  rpmCtx.stroke();

  const haloInnerRpm = ringRadiusRpm - 2;
  const haloOuterRpm = ringRadiusRpm + 8;

  const haloGradRpm = rpmCtx.createRadialGradient(
    0, 0, haloInnerRpm,
    0, 0, haloOuterRpm
  );
  haloGradRpm.addColorStop(0.0, "rgba(255, 200, 80, 0.35)");
  haloGradRpm.addColorStop(0.5, "rgba(255, 160, 40, 0.18)");
  haloGradRpm.addColorStop(1.0, "rgba(0, 0, 0, 0)");

  rpmCtx.fillStyle = haloGradRpm;
  rpmCtx.beginPath();
  rpmCtx.arc(0, 0, haloOuterRpm, 0, Math.PI * 2);
  rpmCtx.arc(0, 0, haloInnerRpm, 0, Math.PI * 2, true);
  rpmCtx.closePath();
  rpmCtx.fill();

  // dải sáng rpm
  const glowInnerR = innerBlackRadius * 1.0;
  const glowOuterR = outerRadius * 1.0;
  const baseAlpha  = 0.04;
  const extraAlpha = 0.08 * frac;

  const glowGradRpm = rpmCtx.createRadialGradient(
    0, 0, glowInnerR,
    0, 0, glowOuterR
  );
  glowGradRpm.addColorStop(
    0.0,
    `rgba(255, 245, 220, ${baseAlpha + extraAlpha * 1.6})`
  );
  glowGradRpm.addColorStop(
    0.35,
    `rgba(255, 210, 150, ${baseAlpha + extraAlpha})`
  );
  glowGradRpm.addColorStop(
    1.0,
    `rgba(255, 180, 90, 0)`
  );

  rpmCtx.fillStyle = glowGradRpm;
  rpmCtx.beginPath();
  rpmCtx.arc(0, 0, glowOuterR, startAngle, startAngle + activeSweep);
  rpmCtx.arc(
    0,
    0,
    glowInnerR,
    startAngle + activeSweep,
    startAngle,
    true
  );
  rpmCtx.closePath();
  rpmCtx.fill();

  // kim rpm
  const angleNeedle = startAngle + sweepAngle * frac;
  rpmCtx.save();
  rpmCtx.rotate(angleNeedle);

  const pivotRadius = innerBlackRadius + (outerRadius - innerBlackRadius) * 0.38;
  rpmCtx.translate(pivotRadius, 0);

  const needleLength = outerRadius - pivotRadius - 3;
  const halfWidth = 3;

  const needleGrad = rpmCtx.createLinearGradient(
    0,
    0,
    needleLength,
    0
  );
  needleGrad.addColorStop(0, "rgba(255,255,255,0.05)");
  needleGrad.addColorStop(0.4, "#ffb03a");
  needleGrad.addColorStop(1, "#ff7a00");

  rpmCtx.fillStyle = needleGrad;
  rpmCtx.beginPath();
  rpmCtx.moveTo(0, -halfWidth);
  rpmCtx.lineTo(needleLength, 0);
  rpmCtx.lineTo(0, halfWidth);
  rpmCtx.closePath();
  rpmCtx.fill();

  rpmCtx.restore();

  // vòng nhiên liệu E/F
  drawFuelArcOnRpm(rpmCtx, radius, fuelPercent);

  rpmCtx.restore();
}

// vạch + số rpm – vạch 0.5 rõ hơn
function drawRpmTicksAndLabels(ctx, startAngle, sweepAngle, radius) {
  const max = MAX_RPM_CANVAS;
  const minorStep = 0.5;
  const majorStep = 1;

  ctx.save();

  for (let v = 0; v <= max + 1e-6; v += minorStep) {
    const frac  = v / max;
    const angle = startAngle + sweepAngle * frac;

    const isBig =
      Math.abs(v % majorStep) < 1e-6 || Math.abs(v - max) < 1e-6;
    const isDangerZone = v >= 6.5 - 1e-6;

    const outerR = radius;
    const innerR = radius - (isBig ? 18 : 12); // vạch nhỏ cũng dài hơn

    const cosA = Math.cos(angle);
    const sinA = Math.sin(angle);

    const outerX = outerR * cosA;
    const outerY = outerR * sinA;
    const innerX = innerR * cosA;
    const innerY = innerR * sinA;

    // bóng dưới vạch
    ctx.beginPath();
    ctx.lineWidth   = isBig ? 3.6 : 2.4;
    ctx.strokeStyle = "rgba(0,0,0,0.6)";
    ctx.moveTo(innerX + 1.2 * cosA, innerY + 1.2 * sinA);
    ctx.lineTo(outerX + 1.2 * cosA, outerY + 1.2 * sinA);
    ctx.stroke();

    // vạch chính
    const grad = ctx.createLinearGradient(innerX, innerY, outerX, outerY);

    if (isDangerZone) {
      grad.addColorStop(0.0, "#4b000a");
      grad.addColorStop(0.4, "#ff9aa5");
      grad.addColorStop(0.8, "#ff3b4b");
      grad.addColorStop(1.0, "#2b0005");
    } else {
      if (isBig) {
        grad.addColorStop(0.0, "#1f222a");
        grad.addColorStop(0.4, "#f9f2da");
        grad.addColorStop(0.8, "#c9b27a");
        grad.addColorStop(1.0, "#4d4024");
      } else {
        grad.addColorStop(0.0, "rgba(230,230,235,0.8)");
        grad.addColorStop(1.0, "rgba(160,160,175,0.95)");
      }
    }

    ctx.beginPath();
    ctx.lineWidth   = isBig ? 3.0 : 2.2;
    ctx.strokeStyle = grad;
    ctx.moveTo(innerX, innerY);
    ctx.lineTo(outerX, outerY);
    ctx.stroke();

    if (isBig) {
      const labelR = radius - 26;
      const lx = labelR * cosA;
      const ly = labelR * sinA;

      ctx.save();
      ctx.translate(lx, ly);
      const textStr = String(Math.round(v));

      ctx.font = "15px system-ui";
      ctx.textAlign = "center";
      ctx.textBaseline = "middle";

      ctx.fillStyle = "rgba(0,0,0,0.85)";
      ctx.fillText(textStr, 1.2, 1.4);

      const textGrad = ctx.createLinearGradient(-10, -8, 10, 8);
      if (isDangerZone) {
        textGrad.addColorStop(0.0, "#5a050f");
        textGrad.addColorStop(0.4, "#ffb0b8");
        textGrad.addColorStop(0.8, "#ff4d5a");
        textGrad.addColorStop(1.0, "#2b0207");
      } else {
        textGrad.addColorStop(0.0, "#f3e0b2");
        textGrad.addColorStop(0.5, "#fff9e1");
        textGrad.addColorStop(1.0, "#7a5b26");
      }

      ctx.fillStyle = textGrad;
      ctx.fillText(textStr, 0, 0);

      ctx.lineWidth = 0.8;
      ctx.strokeStyle = "rgba(255,255,255,0.55)";
      ctx.strokeText(textStr, 0, 0);

      ctx.restore();
    }
  }

  ctx.restore();
}

// fuel arc E/F trên rpm
function drawFuelArcOnRpm(ctx, radius, fuelPercent) {
  ctx.save();

  const margin     = 6;
  const fuelRadius = radius - margin;

  const angleE = degToRad(-45);
  const angleF = degToRad(45);

  const frac = Math.max(0, Math.min(1, fuelPercent / 100));

  const numTicks = 50;
  for (let i = 0; i <= numTicks; i++) {
    const t   = i / numTicks;
    const ang = angleF + (angleE - angleF) * t;

    const rOuter = fuelRadius + 4;
    const rInner = fuelRadius - 5;

    const xOuter = rOuter * Math.cos(ang);
    const yOuter = rOuter * Math.sin(ang);
    const xInner = rInner * Math.cos(ang);
    const yInner = rInner * Math.sin(ang);

    const active = t <= frac + 1e-4;

    let color;
    if (!active) {
      color = "rgba(255,255,255,0.18)";
    } else {
      if (t < 0.5) {
        const k = t / 0.5;
        const r = 255;
        const g = Math.round(75 + (206 - 75) * k);
        const b = Math.round(43 + (58 - 43) * k);
        color = `rgba(${r},${g},${b},0.95)`;
      } else {
        const k = (t - 0.5) / 0.5;
        const r = Math.round(255 + (0 - 255) * k);
        const g = Math.round(206 + (255 - 206) * k);
        const b = Math.round(58 + (157 - 58) * k);
        color = `rgba(${r},${g},${b},0.95)`;
      }
    }

    ctx.beginPath();
    ctx.lineWidth   = 4;
    ctx.strokeStyle = color;
    ctx.moveTo(xInner, yInner);
    ctx.lineTo(xOuter, yOuter);
    ctx.stroke();
  }

  const labelRadius = fuelRadius + 16;
  ctx.fillStyle     = "#ffffff";
  ctx.font          = "13px system-ui";
  ctx.textAlign     = "center";
  ctx.textBaseline  = "middle";

  const xE = labelRadius * Math.cos(angleE);
  const yE = labelRadius * Math.sin(angleE);
  ctx.fillText("F", xE, yE);

  const xF = labelRadius * Math.cos(angleF);
  const yF = labelRadius * Math.sin(angleF);
  ctx.fillText("E", xF, yF);

  ctx.restore();
}

// =================== COOLANT/FUEL DETAIL ===================

function updateCoolantDetail() {
  if (coolantDetailValueEl) {
    coolantDetailValueEl.textContent = Math.round(currentCoolantC);
  }
  if (fuelDetailValueEl) {
    fuelDetailValueEl.textContent = Math.round(currentFuelPercentRaw);
  }
}

// =================== CẢNH BÁO (WARNINGS) ===================

function updateWarnings() {
  // KHÔNG đổi màu icon dưới 2 gauge nữa – chỉ báo bằng 3 ô WARNINGS
  // (nếu muốn dùng lại thì bỏ comment 2 dòng dưới)
  // if (fuelIconEl)    fuelIconEl.classList.remove("icon-warning");
  // if (coolantIconEl) coolantIconEl.classList.remove("icon-warning");

  // Reset 3 ô WARNINGS về trạng thái bình thường
  if (warnSpeedTileEl)   warnSpeedTileEl.classList.remove("warning-tile-active");
  if (warnFuelTileEl)    warnFuelTileEl.classList.remove("warning-tile-active");
  if (warnCoolantTileEl) warnCoolantTileEl.classList.remove("warning-tile-active");

  // 1) NHIÊN LIỆU THẤP
  if (currentFuelPercentRaw < FUEL_WARN_THRESHOLD) {
    if (warnFuelTileEl) warnFuelTileEl.classList.add("warning-tile-active");
  }

  // 2) NHIỆT ĐỘ ĐỘNG CƠ CAO
  if (currentCoolantC > COOLANT_WARN_THRESHOLD) {
    if (warnCoolantTileEl) warnCoolantTileEl.classList.add("warning-tile-active");
  }

  // 3) TỐC ĐỘ / RPM CAO -> dùng chung ô SPEED
  if (currentSpeed >= SPEED_WARN_THRESHOLD || currentRpm >= RPM_WARN_THRESHOLD) {
    if (warnSpeedTileEl) warnSpeedTileEl.classList.add("warning-tile-active");
  }
}


// =================== UPDATE HÀM PUBLIC ===================

function updateSpeed(kmh) {
  const v = clamp(kmh, SPEED_MIN, SPEED_MAX);
  currentSpeed = v;
  if (speedValueEl) {
    speedValueEl.textContent = Math.round(v);
  }
  drawSpeedGauge();
  updateGearFromSpeed(v);
  updateWarnings();
}

function updateRpm(rpm) {
  const v = clamp(rpm, RPM_MIN, RPM_MAX);
  const k = v / 1000;
  currentRpmK = clamp(k, 0, MAX_RPM_CANVAS);
  currentRpm  = v;
  if (rpmValueEl) {
    rpmValueEl.textContent = currentRpmK.toFixed(1);
  }
  drawRpmGauge();
  updateWarnings();
}

function updateOdometer(km) {
  const v = Math.max(0, km);
  const txt = Math.floor(v).toString().padStart(6, "0");

  if (odometerValueEl) {
    odometerValueEl.innerHTML = txt
      .split("")
      .map(ch => `<span class="odometer-digit">${ch}</span>`)
      .join("");
  }
}

function updateCoolant(tempC) {
  const t = clamp(tempC, COOLANT_MIN, COOLANT_MAX);
  currentCoolantC = t;
  const ratio = valueToRatio(t, COOLANT_MIN, COOLANT_MAX);
  currentCoolantPct = ratio * 100;
  drawSpeedGauge();
  updateCoolantDetail();
  updateWarnings();
}

function updateFuel(fuelPercent) {
  const v = clamp(fuelPercent, FUEL_MIN, FUEL_MAX);
  currentFuelPercentRaw = v;
  const ratio = valueToRatio(v, FUEL_MIN, FUEL_MAX);
  currentFuelPct = ratio * 100;
  drawRpmGauge();
  updateCoolantDetail();
  updateWarnings();
}

// API debug
window.hmiUpdate = function (data) {
  if (typeof data.speed === "number")    updateSpeed(data.speed);
  if (typeof data.rpm === "number")      updateRpm(data.rpm);
  if (typeof data.coolant === "number")  updateCoolant(data.coolant);
  if (typeof data.fuel === "number")     updateFuel(data.fuel);
  if (typeof data.odometer === "number") updateOdometer(data.odometer);
};

// =================== TIME BAR ===================
function updateDateTime() {
  const now = new Date();
  const dd = String(now.getDate()).padStart(2, "0");
  const mm = String(now.getMonth() + 1).padStart(2, "0");
  const hh = String(now.getHours()).padStart(2, "0");
  const mi = String(now.getMinutes()).padStart(2, "0");
  if (topDateEl) topDateEl.textContent = `${dd}/${mm}`;
  if (topTimeEl) topTimeEl.textContent = `${hh}:${mi}`;
}
updateDateTime();
setInterval(updateDateTime, 1000);

// =================== FIREBASE SUBSCRIBE ===================
const obdRef = ref(db, "obd");

onValue(
  obdRef,
  (snapshot) => {
    const d = snapshot.val() || {};

    const coolant = Number(d["Engine Coolant Temperature"] ?? 0);
    const rpm     = Number(d["Engine RPM"] ?? 0);
    const fuel    = Number(d["Fuel Level Input"] ?? 0);
    const odo     = Number(d["Odometer"] ?? 0);
    const speed   = Number(d["Vehicle Speed"] ?? 0);

    window.hmiUpdate({
      speed,
      rpm,
      coolant,
      fuel,
      odometer: odo
    });
  },
  (err) => console.error("Firebase OBD listener error:", err)
);

// =================== STATE BAN ĐẦU ===================
window.hmiUpdate({
  speed: 0,
  rpm: 0,
  coolant: 40,
  fuel: 50,
  odometer: 0
});
