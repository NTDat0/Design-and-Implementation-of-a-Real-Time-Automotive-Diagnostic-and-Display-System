#include "main.h"
#include "spi.h"
#include "CANSPI.h"

uCAN_MSG txMsg, rxMsg;
uint8_t pids[] = {0x0D, 0x0C, 0x05, 0x2F, 0xA6};

/* --- STORE DATA HERE (Dữ liệu sau khi giải mã nằm ở đây) --- */
typedef struct {
    int speed_kmh;
    float rpm;
    int temp_c;
    float fuel_pct;
    uint32_t odo_km;
} DashboardData;

DashboardData MyCarData; // <--- XEM BIẾN NÀY TRONG DEBUGGER

/* Hàm giải mã dữ liệu thô từ CAN thành số thực tế */
void Decode_OBD(uint8_t pid, uint8_t *data) {
    // data[3]=A, data[4]=B, data[5]=C, data[6]=D
    uint8_t A = data[3];
    uint8_t B = data[4];

    switch(pid) {
        case 0x0D: // Speed
            MyCarData.speed_kmh = A;
            break;

        case 0x0C: // RPM = ((A*256)+B)/4
            MyCarData.rpm = ((float)A * 256.0f + (float)B) / 4.0f;
            break;

        case 0x05: // Temp = A - 40
            MyCarData.temp_c = (int)A - 40;
            break;

        case 0x2F: // Fuel = A * 100 / 255
            MyCarData.fuel_pct = (float)A * 100.0f / 255.0f;
            break;

        case 0xA6: // ODO (4 bytes A,B,C,D)
            MyCarData.odo_km = (uint32_t)A << 24 |
                               (uint32_t)B << 16 |
                               (uint32_t)data[5] << 8 |
                               (uint32_t)data[6];
            break;
    }
}

int main(void) {
    HAL_Init();
    SystemClock_Config();
    MX_GPIO_Init();
    MX_SPI1_Init();
    CANSPI_Initialize();

    uint8_t idx = 0;

    while (1) {
            txMsg.frame.idType = dSTANDARD_CAN_MSG_ID_2_0B; // <--- THÊM DÒNG NÀY

            txMsg.frame.id = 0x7DF;          // ID chuẩn OBD-II
            txMsg.frame.dlc = 8;             // Độ dài dữ liệu
            txMsg.frame.data0 = 0x02;        // Số byte dữ liệu thực (Mode + PID)
            txMsg.frame.data1 = 0x01;        // Mode 01
            txMsg.frame.data2 = pids[idx];   // PID muốn hỏi

            // Xóa sạch các byte còn lại để tránh gửi rác
            txMsg.frame.data3 = 0; txMsg.frame.data4 = 0;
            txMsg.frame.data5 = 0; txMsg.frame.data6 = 0; txMsg.frame.data7 = 0;

            /* 2. Gửi đi */
            CANSPI_Transmit(&txMsg);

            /* 3. Chờ phản hồi (Timeout 50ms) */
            uint32_t start = HAL_GetTick();
            while (HAL_GetTick() - start < 50) {
                if (CANSPI_Receive(&rxMsg)) {
                    // Check ID 7E8 (Standard) và đúng PID
                    if (rxMsg.frame.id == 0x7E8 && rxMsg.frame.data2 == pids[idx]) {

                        // Gom mảng fix lỗi compile lần trước
                        uint8_t temp_buffer[8];
                        temp_buffer[0] = rxMsg.frame.data0;
                        temp_buffer[1] = rxMsg.frame.data1;
                        temp_buffer[2] = rxMsg.frame.data2;
                        temp_buffer[3] = rxMsg.frame.data3;
                        temp_buffer[4] = rxMsg.frame.data4;
                        temp_buffer[5] = rxMsg.frame.data5;
                        temp_buffer[6] = rxMsg.frame.data6;
                        temp_buffer[7] = rxMsg.frame.data7;

                        Decode_OBD(pids[idx], temp_buffer);
                        break;
                    }
                }
            }

            /* 4. Next PID */
            idx++;
            if (idx >= sizeof(pids)) idx = 0;

            HAL_Delay(200);
        }
}


void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.HSEPredivValue = RCC_HSE_PREDIV_DIV1;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLMUL = RCC_PLL_MUL9;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK) Error_Handler();

  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK) Error_Handler();
}

void Error_Handler(void)
{
  __disable_irq();
  while (1) {}
}
