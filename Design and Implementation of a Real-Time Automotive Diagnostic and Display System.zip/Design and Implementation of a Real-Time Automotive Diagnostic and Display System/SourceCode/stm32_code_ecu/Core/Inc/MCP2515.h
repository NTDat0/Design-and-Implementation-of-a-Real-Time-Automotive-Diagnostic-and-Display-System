#ifndef __MCP2515_H
#define __MCP2515_H

#include "main.h"
#include <stdint.h>
#include <stdbool.h>

// MCP2515 SPI Instructions
#define MCP2515_RESET           0xC0
#define MCP2515_READ            0x03
#define MCP2515_READ_RX         0x90
#define MCP2515_WRITE           0x02
#define MCP2515_LOAD_TX         0x40
#define MCP2515_RTS             0x80
#define MCP2515_READ_STATUS     0xA0
#define MCP2515_RX_STATUS       0xB0
#define MCP2515_BIT_MODIFY      0x05

// Register Addresses
#define MCP2515_RXF0SIDH        0x00
#define MCP2515_RXF0SIDL        0x01
#define MCP2515_RXF0EID8        0x02
#define MCP2515_RXF0EID0        0x03
#define MCP2515_RXF1SIDH        0x04
#define MCP2515_RXF1SIDL        0x05
#define MCP2515_RXF1EID8        0x06
#define MCP2515_RXF1EID0        0x07
#define MCP2515_RXF2SIDH        0x08
#define MCP2515_RXF2SIDL        0x09
#define MCP2515_RXF2EID8        0x0A
#define MCP2515_RXF2EID0        0x0B
#define MCP2515_CANSTAT         0x0E
#define MCP2515_CANCTRL         0x0F
#define MCP2515_TXB0CTRL        0x30
#define MCP2515_TXB1CTRL        0x40
#define MCP2515_TXB2CTRL        0x50
#define MCP2515_RXB0CTRL        0x60
#define MCP2515_RXB1CTRL        0x70
#define MCP2515_BFPCTRL         0x0C
#define MCP2515_TXRTSCTRL       0x0D
#define MCP2515_CANINTE         0x2B
#define MCP2515_CANINTF         0x2C
#define MCP2515_EFLG            0x2D
#define MCP2515_CNF3            0x28
#define MCP2515_CNF2            0x29
#define MCP2515_CNF1            0x2A
#define MCP2515_CANCTRL         0x0F
#define MCP2515_TXB0SIDH        0x31
#define MCP2515_TXB0SIDL        0x32
#define MCP2515_TXB0EID8        0x33
#define MCP2515_TXB0EID0        0x34
#define MCP2515_TXB0DLC         0x35
#define MCP2515_TXB0D0          0x36
#define MCP2515_RXB0SIDH        0x61
#define MCP2515_RXB0SIDL        0x62
#define MCP2515_RXB0EID8        0x63
#define MCP2515_RXB0EID0        0x64
#define MCP2515_RXB0DLC         0x65
#define MCP2515_RXB0D0          0x66

// CANCTRL Register Bits
#define MODE_NORMAL             0x00
#define MODE_SLEEP              0x20
#define MODE_LOOPBACK           0x40
#define MODE_LISTENONLY         0x60
#define MODE_CONFIG             0x80
#define MODE_POWERUP            0xE0
#define MODE_MASK               0xE0
#define ABORT_TX                0x10
#define MODE_ONESHOT            0x08
#define CLKOUT_ENABLE           0x04
#define CLKOUT_DISABLE          0x00
#define CLKOUT_PS1              0x00
#define CLKOUT_PS2              0x01
#define CLKOUT_PS4              0x02
#define CLKOUT_PS8              0x03

// RX Buffer Control
#define RXB0_DBEN               0x04
#define RXB0_RXM                0x60

// RTS
#define MCP2515_RTS_TX0         0x01
#define MCP2515_RTS_TX1         0x02
#define MCP2515_RTS_TX2         0x04

// Read RX Sequence
#define MCP2515_READ_RXB0SIDH   0x90
#define MCP2515_READ_RXB0D0     0x92
#define MCP2515_READ_RXB1SIDH   0x94
#define MCP2515_READ_RXB1D0     0x96

// Load TX
#define MCP2515_LOAD_TXB0SIDH   0x40
#define MCP2515_LOAD_TXB0D0     0x41
#define MCP2515_LOAD_TXB1SIDH   0x42
#define MCP2515_LOAD_TXB1D0     0x43
#define MCP2515_LOAD_TXB2SIDH   0x44
#define MCP2515_LOAD_TXB2D0     0x45

#define MCP2515_CS_HIGH()       HAL_GPIO_WritePin(GPIOA, GPIO_PIN_4, GPIO_PIN_SET)
#define MCP2515_CS_LOW()        HAL_GPIO_WritePin(GPIOA, GPIO_PIN_4, GPIO_PIN_RESET)

// Structs
typedef struct {
  uint8_t tempSIDH;
  uint8_t tempSIDL;
  uint8_t tempEID8;
  uint8_t tempEID0;
} id_reg_t;

typedef struct {
  uint8_t RXFnSIDH;
  uint8_t RXFnSIDL;
  uint8_t RXFnEID8;
  uint8_t RXFnEID0;
} RXF;

typedef struct {
  uint8_t RXMnSIDH;
  uint8_t RXMnSIDL;
  uint8_t RXMnEID8;
  uint8_t RXMnEID0;
} RXM;

// Function Prototypes
void MCP2515_Reset(void);
void MCP2515_WriteByte(uint8_t address, uint8_t data);
uint8_t MCP2515_ReadByte(uint8_t address);
void MCP2515_WriteByteSequence(uint8_t startAddress, uint8_t endAddress, uint8_t *data);
void MCP2515_ReadRxSequence(uint8_t instruction, uint8_t *data, uint8_t length);
void MCP2515_RequestToSend(uint8_t instruction);
uint8_t MCP2515_ReadStatus(void);
void MCP2515_BitModify(uint8_t address, uint8_t mask, uint8_t data);
bool MCP2515_SetConfigMode(void);
bool MCP2515_SetNormalMode(void);
void MCP2515_SetSleepMode(void);


#endif
