// CANSPI.h
#ifndef __CANSPI_H
#define __CANSPI_H

#include "main.h"
#include <stdint.h>
#include <stdbool.h>

typedef union {
  struct {
    uint8_t idType;
    uint32_t id;
    uint8_t dlc;
    uint8_t data0;
    uint8_t data1;
    uint8_t data2;
    uint8_t data3;
    uint8_t data4;
    uint8_t data5;
    uint8_t data6;
    uint8_t data7;
  } frame;
  uint8_t array[14];
} uCAN_MSG;

#define dSTANDARD_CAN_MSG_ID_2_0B 1
#define dEXTENDED_CAN_MSG_ID_2_0B 2

// MCP2515 REGISTERS - CHUẨN
#define MCP_TXB0CTRL  0x30
#define MCP_TXB0SIDH  0x31
#define MCP_TXB0SIDL  0x32
#define MCP_TXB0EID8  0x33
#define MCP_TXB0EID0  0x34
#define MCP_TXB0DLC   0x35
#define MCP_TXB0D0    0x36

#define MCP_RXB0CTRL  0x60
#define MCP_RXB0SIDH  0x61
#define MCP_RXB0SIDL  0x62
#define MCP_RXB0DLC   0x65
#define MCP_RXB0D0    0x66

#define MCP_CANINTF   0x2C
#define MCP_RX0IF     0x01
#define MCP_RX1IF     0x02
#define MCP_TX_REQ    0x08

#define MCP2515_CS_LOW()  HAL_GPIO_WritePin(CAN_CS_2_GPIO_Port, CAN_CS_2_Pin, GPIO_PIN_RESET)
#define MCP2515_CS_HIGH() HAL_GPIO_WritePin(CAN_CS_2_GPIO_Port, CAN_CS_2_Pin, GPIO_PIN_SET)

bool CANSPI_Initialize(void);
bool CANSPI_Transmit(uCAN_MSG *msg);
bool CANSPI_Receive(uCAN_MSG *msg);

#endif
