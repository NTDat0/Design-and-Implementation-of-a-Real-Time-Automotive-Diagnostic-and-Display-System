#include "MCP2515.h"
#include "spi.h"

// DÙNG MACRO CAN_CS ĐỂ ĐIỀU KHIỂN CS
// → 2 STM32 DÙNG CÙNG FILE NÀY, CHỈ KHÁC MACRO

extern SPI_HandleTypeDef hspi1;

void MCP2515_Reset(void)
{
  uint8_t cmd = MCP2515_RESET;
  HAL_GPIO_WritePin(CAN_CS_2_GPIO_Port, CAN_CS_2_Pin, GPIO_PIN_RESET);
  HAL_SPI_Transmit(&hspi1, &cmd, 1, HAL_MAX_DELAY);
  HAL_GPIO_WritePin(CAN_CS_2_GPIO_Port, CAN_CS_2_Pin, GPIO_PIN_SET);
  HAL_Delay(10);
}

void MCP2515_WriteByte(uint8_t address, uint8_t data)
{
  uint8_t tx[3] = {MCP2515_WRITE, address, data};
  HAL_GPIO_WritePin(CAN_CS_2_GPIO_Port, CAN_CS_2_Pin, GPIO_PIN_RESET);
  HAL_SPI_Transmit(&hspi1, tx, 3, HAL_MAX_DELAY);
  HAL_GPIO_WritePin(CAN_CS_2_GPIO_Port, CAN_CS_2_Pin, GPIO_PIN_SET);
}

uint8_t MCP2515_ReadByte(uint8_t address)
{
  uint8_t tx[2] = {MCP2515_READ, address};
  uint8_t rx = 0;
  HAL_GPIO_WritePin(CAN_CS_2_GPIO_Port, CAN_CS_2_Pin, GPIO_PIN_RESET);
  HAL_SPI_Transmit(&hspi1, tx, 2, HAL_MAX_DELAY);
  HAL_SPI_Receive(&hspi1, &rx, 1, HAL_MAX_DELAY);
  HAL_GPIO_WritePin(CAN_CS_2_GPIO_Port, CAN_CS_2_Pin, GPIO_PIN_SET);
  return rx;
}

void MCP2515_WriteByteSequence(uint8_t startAddress, uint8_t endAddress, uint8_t *data)
{
  uint8_t len = endAddress - startAddress + 1;
  uint8_t tx[20];
  if (len > 18) len = 18;
  tx[0] = MCP2515_WRITE;
  tx[1] = startAddress;
  for (int i = 0; i < len; i++) tx[2 + i] = data[i];

  HAL_GPIO_WritePin(CAN_CS_2_GPIO_Port, CAN_CS_2_Pin, GPIO_PIN_RESET);
  HAL_SPI_Transmit(&hspi1, tx, len + 2, HAL_MAX_DELAY);
  HAL_GPIO_WritePin(CAN_CS_2_GPIO_Port, CAN_CS_2_Pin, GPIO_PIN_SET);
}

void MCP2515_ReadRxSequence(uint8_t instruction, uint8_t *data, uint8_t length)
{
  HAL_GPIO_WritePin(CAN_CS_2_GPIO_Port, CAN_CS_2_Pin, GPIO_PIN_RESET);
  HAL_SPI_Transmit(&hspi1, &instruction, 1, HAL_MAX_DELAY);
  HAL_SPI_Receive(&hspi1, data, length, HAL_MAX_DELAY);
  HAL_GPIO_WritePin(CAN_CS_2_GPIO_Port, CAN_CS_2_Pin, GPIO_PIN_SET);
}

void MCP2515_RequestToSend(uint8_t instruction)
{
  uint8_t cmd = MCP2515_RTS | instruction;
  HAL_GPIO_WritePin(CAN_CS_2_GPIO_Port, CAN_CS_2_Pin, GPIO_PIN_RESET);
  HAL_SPI_Transmit(&hspi1, &cmd, 1, HAL_MAX_DELAY);
  HAL_GPIO_WritePin(CAN_CS_2_GPIO_Port, CAN_CS_2_Pin, GPIO_PIN_SET);
}

uint8_t MCP2515_ReadStatus(void)
{
  uint8_t cmd = MCP2515_READ_STATUS;
  uint8_t status;
  HAL_GPIO_WritePin(CAN_CS_2_GPIO_Port, CAN_CS_2_Pin, GPIO_PIN_RESET);
  HAL_SPI_Transmit(&hspi1, &cmd, 1, HAL_MAX_DELAY);
  HAL_SPI_Receive(&hspi1, &status, 1, HAL_MAX_DELAY);
  HAL_GPIO_WritePin(CAN_CS_2_GPIO_Port, CAN_CS_2_Pin, GPIO_PIN_SET);
  return status;
}

void MCP2515_BitModify(uint8_t address, uint8_t mask, uint8_t data)
{
  uint8_t tx[4] = {MCP2515_BIT_MODIFY, address, mask, data};
  HAL_GPIO_WritePin(CAN_CS_2_GPIO_Port, CAN_CS_2_Pin, GPIO_PIN_RESET);
  HAL_SPI_Transmit(&hspi1, tx, 4, HAL_MAX_DELAY);
  HAL_GPIO_WritePin(CAN_CS_2_GPIO_Port, CAN_CS_2_Pin, GPIO_PIN_SET);
}

bool MCP2515_SetConfigMode(void)
{
  MCP2515_WriteByte(MCP2515_CANCTRL, MODE_CONFIG);
  HAL_Delay(10);
  return (MCP2515_ReadByte(MCP2515_CANSTAT) & MODE_MASK) == MODE_CONFIG;
}

bool MCP2515_SetNormalMode(void)
{
  MCP2515_WriteByte(MCP2515_CANCTRL, MODE_NORMAL);
  HAL_Delay(10);
  return (MCP2515_ReadByte(MCP2515_CANSTAT) & MODE_MASK) == MODE_NORMAL;
}

void MCP2515_SetSleepMode(void)
{
  MCP2515_WriteByte(MCP2515_CANCTRL, MODE_SLEEP);
}
