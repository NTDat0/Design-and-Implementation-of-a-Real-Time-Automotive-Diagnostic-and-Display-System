/* ECU SIMULATOR - SAE J1979 STANDARD COMPLIANT */
#include "main.h"
#include "spi.h"
#include "CANSPI.h"
#include <math.h>

/* --- CẤU HÌNH XE --- */
#define IDLE_RPM        800.0f
#define MAX_RPM         7000.0f
#define GEAR_RATIO      45.0f
#define START_ODO_KM    2000.0f
#define FUEL_RESET_TH   10.0f

/* Trạng thái xe (Physical Values) */
struct {
    float speed_kph;
    float rpm;
    float temp_c;
    float fuel_pct;
    double odometer_km;

    int8_t  accel_dir;
    uint32_t last_tick;
} Car = {
    .speed_kph = 0.0f,
    .rpm = IDLE_RPM,
    .temp_c = 85.0f,
    .fuel_pct = 100.0f,
    .odometer_km = START_ODO_KM,
    .accel_dir = 1,
    .last_tick = 0
};

uCAN_MSG rxMsg, txMsg;

/* LOGIC MÔ PHỎNG VẬT LÝ (PHYSICS ENGINE) */
void Physics_Update(void) {
    uint32_t now = HAL_GetTick();
    if (now - Car.last_tick < 10) return;

    float dt_s = (now - Car.last_tick) / 1000.0f;
    Car.last_tick = now;

    /* 1. Tốc độ & ODO */
    if (Car.accel_dir == 1) {
        Car.speed_kph += 25.0f * dt_s; // Tăng tốc
        if (Car.speed_kph >= 130.0f) Car.accel_dir = -1;
    } else {
        Car.speed_kph -= 15.0f * dt_s; // Giảm tốc
        if (Car.speed_kph <= 0.0f) {
            Car.speed_kph = 0.0f;
            Car.accel_dir = 1;
        }
    }

    // Cộng dồn quãng đường: S = v * t
    Car.odometer_km += (Car.speed_kph * dt_s) / 3600.0;

    /* 2. RPM (Tỉ lệ thuận Speed) */
    Car.rpm = IDLE_RPM + (Car.speed_kph * GEAR_RATIO);
    if (Car.rpm > MAX_RPM) Car.rpm = MAX_RPM;

    /* 3. Nhiệt độ (Tăng theo RPM) */
    float target_temp = (Car.rpm > 3500.0f) ? 108.0f : 90.0f;
    if (Car.temp_c < target_temp) Car.temp_c += 0.6f * dt_s;
    else Car.temp_c -= 0.4f * dt_s;

    /* 4. Nhiên liệu (Giảm theo RPM) */
    float consumption = (Car.rpm / MAX_RPM) * 1.5f * dt_s; // Hết nhanh để dễ test
    Car.fuel_pct -= consumption;
    if (Car.fuel_pct <= FUEL_RESET_TH) Car.fuel_pct = 100.0f; // Auto Refill
}

/* MÃ HÓA THEO CHUẨN OBD-II (ENCODING) */
void Build_OBD_Response(uint8_t pid, uCAN_MSG *tx) {
    // [FIX LỖI] ID Type bắt buộc phải là Standard để ra 7E8
    tx->frame.idType = dSTANDARD_CAN_MSG_ID_2_0B;
    tx->frame.id = 0x7E8;
    tx->frame.dlc = 8;

    // Byte 0: Length, Byte 1: Mode (0x41), Byte 2: PID
    tx->frame.data1 = 0x41;
    tx->frame.data2 = pid;
    // Xóa đệm
    tx->frame.data3=0; tx->frame.data4=0; tx->frame.data5=0; tx->frame.data6=0; tx->frame.data7=0;

    switch (pid) {
        case 0x0D: // PID 0D: Vehicle Speed
            // Chuẩn: A = km/h
            tx->frame.data0 = 0x03; // Len = 3
            tx->frame.data3 = (uint8_t)Car.speed_kph;
            break;

        case 0x0C: // PID 0C: Engine RPM
            // Chuẩn: RPM = (256*A + B) / 4  =>  (256*A + B) = RPM * 4
            {
                uint16_t raw = (uint16_t)(Car.rpm * 4.0f);
                tx->frame.data0 = 0x04; // Len = 4
                tx->frame.data3 = (raw >> 8) & 0xFF; // Byte A (High)
                tx->frame.data4 = raw & 0xFF;        // Byte B (Low)
            }
            break;

        case 0x05: // PID 05: Coolant Temp
            // Chuẩn: Temp = A - 40  =>  A = Temp + 40
            tx->frame.data0 = 0x03;
            tx->frame.data3 = (uint8_t)(Car.temp_c + 40.0f);
            break;

        case 0x2F: // PID 2F: Fuel Level
            // Chuẩn: Level = (100/255)*A  =>  A = Level * (255/100)
            tx->frame.data0 = 0x03;
            tx->frame.data3 = (uint8_t)(Car.fuel_pct * 2.55f);
            break;

        case 0xA6: // PID A6: Odometer (Custom Standard)
            // Quy ước: ODO = Raw * 0.1  =>  Raw = ODO * 10
            {
                uint32_t raw_odo = (uint32_t)(Car.odometer_km * 10.0);
                tx->frame.data0 = 0x06; // Len = 6 (Mode+PID+4Bytes)
                tx->frame.data3 = (raw_odo >> 24) & 0xFF;
                tx->frame.data4 = (raw_odo >> 16) & 0xFF;
                tx->frame.data5 = (raw_odo >> 8)  & 0xFF;
                tx->frame.data6 = raw_odo & 0xFF;
            }
            break;

        default: // PID Not Supported
             tx->frame.data0 = 0x03; tx->frame.data1 = 0x7F; tx->frame.data2 = 0x01; tx->frame.data3 = 0x12;
             break;
    }
}

int main(void) {
    HAL_Init();
    SystemClock_Config();
    MX_GPIO_Init();
    MX_SPI1_Init();
    CANSPI_Initialize();

    while (1) {
        Physics_Update();

        if (CANSPI_Receive(&rxMsg)) {
            // Lắng nghe 7DF (Standard ID)
            if (rxMsg.frame.id == 0x7DF && rxMsg.frame.data1 == 0x01) {
                Build_OBD_Response(rxMsg.frame.data2, &txMsg);
                CANSPI_Transmit(&txMsg);
            }
        }
    }
}

void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.HSEPredivValue = RCC_HSE_PREDIV_DIV1;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLMUL = RCC_PLL_MUL9;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK) while(1);

  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK) while(1);
}
void Error_Handler(void)
{
  __disable_irq();
  while (1) {}
}
