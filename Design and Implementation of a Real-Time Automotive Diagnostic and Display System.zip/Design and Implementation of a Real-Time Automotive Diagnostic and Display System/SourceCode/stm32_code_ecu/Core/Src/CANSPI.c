// CANSPI.c - HOÀN CHỈNH, ĐỌC ĐÚNG DLC
#include "CANSPI.h"
#include "spi.h"

static void mcp2515_reset(void) {
  uint8_t cmd = 0xC0;
  MCP2515_CS_LOW();
  HAL_SPI_Transmit(&hspi1, &cmd, 1, 100);
  MCP2515_CS_HIGH();
  HAL_Delay(10);
}

static void mcp2515_write_reg(uint8_t addr, uint8_t val) {
  MCP2515_CS_LOW();
  uint8_t buf[3] = {0x02, addr, val};
  HAL_SPI_Transmit(&hspi1, buf, 3, 100);
  MCP2515_CS_HIGH();
}

static uint8_t mcp2515_read_reg(uint8_t addr) {
  uint8_t val;
  MCP2515_CS_LOW();
  uint8_t buf[2] = {0x03, addr};
  HAL_SPI_Transmit(&hspi1, buf, 2, 100);
  HAL_SPI_Receive(&hspi1, &val, 1, 100);
  MCP2515_CS_HIGH();
  return val;
}

static void mcp2515_bit_modify(uint8_t addr, uint8_t mask, uint8_t data) {
  MCP2515_CS_LOW();
  uint8_t buf[4] = {0x05, addr, mask, data};
  HAL_SPI_Transmit(&hspi1, buf, 4, 100);
  MCP2515_CS_HIGH();
}

bool CANSPI_Initialize(void) {
  MCP2515_CS_HIGH();
  HAL_Delay(10);
  mcp2515_reset();
  HAL_Delay(10);

  mcp2515_write_reg(0x0F, 0x80); // Config mode
  HAL_Delay(1);

  mcp2515_write_reg(0x2A, 0x00); // CNF1
  mcp2515_write_reg(0x29, 0xB1); // CNF2
  mcp2515_write_reg(0x28, 0x05); // CNF3

  mcp2515_write_reg(0x60, 0x04); // RXB0: nhận tất cả
  mcp2515_write_reg(0x2B, 0x03); // INTE: RX0IF + RX1IF

  mcp2515_write_reg(0x0F, 0x00); // Normal mode
  HAL_Delay(10);

  return (mcp2515_read_reg(0x0E) & 0xE0) == 0x00;
}

bool CANSPI_Transmit(uCAN_MSG *msg) {
  if (mcp2515_read_reg(MCP_TXB0CTRL) & MCP_TX_REQ) return false;

  if (msg->frame.idType == dSTANDARD_CAN_MSG_ID_2_0B) {
    mcp2515_write_reg(MCP_TXB0SIDH, (msg->frame.id >> 3) & 0xFF);
    mcp2515_write_reg(MCP_TXB0SIDL, (msg->frame.id << 5) & 0xE0);
    mcp2515_write_reg(MCP_TXB0EID8, 0x00);
    mcp2515_write_reg(MCP_TXB0EID0, 0x00);
  }

  mcp2515_write_reg(MCP_TXB0DLC, msg->frame.dlc & 0x0F);
  for (int i = 0; i < 8; i++) {
    mcp2515_write_reg(MCP_TXB0D0 + i, ((uint8_t*)&msg->frame.data0)[i]);
  }

  mcp2515_bit_modify(MCP_TXB0CTRL, MCP_TX_REQ, MCP_TX_REQ);

  uint32_t timeout = HAL_GetTick() + 10;
  while (mcp2515_read_reg(MCP_TXB0CTRL) & MCP_TX_REQ) {
    if (HAL_GetTick() > timeout) return false;
  }
  return true;
}

bool CANSPI_Receive(uCAN_MSG *msg) {
  uint8_t intf = mcp2515_read_reg(MCP_CANINTF);
  if (!(intf & (MCP_RX0IF | MCP_RX1IF))) return false;

  uint8_t base = (intf & MCP_RX0IF) ? 0x60 : 0x70;
  mcp2515_bit_modify(MCP_CANINTF, intf & (MCP_RX0IF | MCP_RX1IF), 0);

  uint8_t sidh = mcp2515_read_reg(base + 1);
  uint8_t sidl = mcp2515_read_reg(base + 2);
  msg->frame.id = ((uint32_t)sidh << 3) | (sidl >> 5);
  msg->frame.idType = (sidl & 0x08) ? dEXTENDED_CAN_MSG_ID_2_0B : dSTANDARD_CAN_MSG_ID_2_0B;

  msg->frame.dlc = mcp2515_read_reg(base + 5) & 0x0F;  // ĐỌC ĐÚNG DLC
  for (int i = 0; i < 8; i++) {
    ((uint8_t*)&msg->frame.data0)[i] = mcp2515_read_reg(base + 6 + i);
  }
  return true;
}
